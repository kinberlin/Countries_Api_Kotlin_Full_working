package com.example.countries.Countries

data class Fra(
    val f: String,
    val m: String
)