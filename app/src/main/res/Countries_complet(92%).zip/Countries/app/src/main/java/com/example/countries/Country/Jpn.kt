package com.example.countries.Country

data class Jpn(
    val common: String,
    val official: String
)