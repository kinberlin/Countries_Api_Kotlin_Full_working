package com.example.countries.Country

data class Flags(
    val png: String,
    val svg: String
)