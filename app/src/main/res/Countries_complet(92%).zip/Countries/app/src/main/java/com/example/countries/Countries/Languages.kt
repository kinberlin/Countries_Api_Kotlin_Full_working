package com.example.countries.Countries

data class Languages(
    val eng: String
)