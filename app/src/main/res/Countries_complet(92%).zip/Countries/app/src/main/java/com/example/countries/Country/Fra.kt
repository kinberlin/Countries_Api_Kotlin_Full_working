package com.example.countries.Country

data class Fra(
    val f: String,
    val m: String
)