package com.example.countries.Countries

class Listes : ArrayList<ListesItem>()