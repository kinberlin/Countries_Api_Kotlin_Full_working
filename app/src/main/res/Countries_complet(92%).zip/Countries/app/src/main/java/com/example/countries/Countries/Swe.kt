package com.example.countries.Countries

data class Swe(
    val common: String,
    val official: String
)