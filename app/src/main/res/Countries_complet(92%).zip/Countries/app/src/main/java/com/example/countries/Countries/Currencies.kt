package com.example.countries.Countries

data class Currencies(
    val XCD: XCD
)