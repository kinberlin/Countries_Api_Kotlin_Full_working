package com.example.countries.Country

data class EngX(
    val common: String,
    val official: String
)