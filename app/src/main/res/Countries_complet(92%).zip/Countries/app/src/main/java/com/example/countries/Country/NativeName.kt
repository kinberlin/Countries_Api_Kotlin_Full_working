package com.example.countries.Country

data class NativeName(
    val eng: EngX,
    val fra: FraX
)