package com.example.countries.Country

data class CoatOfArms(
    val png: String,
    val svg: String
)