package com.example.countries.Countries

data class Demonyms(
    val eng: Eng,
    val fra: Fra
)