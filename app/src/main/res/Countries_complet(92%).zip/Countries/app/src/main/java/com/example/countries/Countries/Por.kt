package com.example.countries.Countries

data class Por(
    val common: String,
    val official: String
)