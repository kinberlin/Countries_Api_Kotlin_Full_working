package com.example.countries.Countries

data class Ara(
    val common: String,
    val official: String
)