package com.example.countries.Country

data class Cym(
    val common: String,
    val official: String
)