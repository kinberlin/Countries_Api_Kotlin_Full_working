package com.example.countries.Country

data class Maps(
    val googleMaps: String,
    val openStreetMaps: String
)