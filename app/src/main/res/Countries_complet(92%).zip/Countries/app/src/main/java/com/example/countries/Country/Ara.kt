package com.example.countries.Country

data class Ara(
    val common: String,
    val official: String
)