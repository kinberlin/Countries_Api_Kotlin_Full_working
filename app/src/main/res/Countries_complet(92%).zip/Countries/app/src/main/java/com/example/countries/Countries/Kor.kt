package com.example.countries.Countries

data class Kor(
    val common: String,
    val official: String
)