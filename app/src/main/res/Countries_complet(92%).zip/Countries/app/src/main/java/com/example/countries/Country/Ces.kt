package com.example.countries.Country

data class Ces(
    val common: String,
    val official: String
)