package com.example.countries.Country

data class Pol(
    val common: String,
    val official: String
)