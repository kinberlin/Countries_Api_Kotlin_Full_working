package com.example.countries.Countries

data class PostalCode(
    val format: String,
    val regex: String
)