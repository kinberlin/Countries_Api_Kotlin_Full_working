package com.example.countries.Countries

data class Fin(
    val common: String,
    val official: String
)