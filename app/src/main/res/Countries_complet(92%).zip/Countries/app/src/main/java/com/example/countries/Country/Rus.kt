package com.example.countries.Country

data class Rus(
    val common: String,
    val official: String
)