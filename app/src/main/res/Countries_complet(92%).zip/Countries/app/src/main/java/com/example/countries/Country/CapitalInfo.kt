package com.example.countries.Country

data class CapitalInfo(
    val latlng: List<Double>
)