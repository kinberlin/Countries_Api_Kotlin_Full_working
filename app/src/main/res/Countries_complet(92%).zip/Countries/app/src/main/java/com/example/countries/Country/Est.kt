package com.example.countries.Country

data class Est(
    val common: String,
    val official: String
)