package com.example.countries.Country

data class Languages(
    val eng: String,
    val fra: String
)