package com.example.countries.Countries

data class Slk(
    val common: String,
    val official: String
)