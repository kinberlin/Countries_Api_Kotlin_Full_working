package com.example.countries.Countries

data class Spa(
    val common: String,
    val official: String
)