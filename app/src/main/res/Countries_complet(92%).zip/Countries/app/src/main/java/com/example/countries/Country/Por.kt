package com.example.countries.Country

data class Por(
    val common: String,
    val official: String
)