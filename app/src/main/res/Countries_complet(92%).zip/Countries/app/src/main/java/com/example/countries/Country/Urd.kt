package com.example.countries.Country

data class Urd(
    val common: String,
    val official: String
)