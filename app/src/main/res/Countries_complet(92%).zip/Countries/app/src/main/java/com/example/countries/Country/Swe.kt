package com.example.countries.Country

data class Swe(
    val common: String,
    val official: String
)