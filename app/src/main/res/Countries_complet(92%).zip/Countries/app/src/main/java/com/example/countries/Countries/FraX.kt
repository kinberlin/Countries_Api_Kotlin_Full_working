package com.example.countries.Countries

data class FraX(
    val common: String,
    val official: String
)