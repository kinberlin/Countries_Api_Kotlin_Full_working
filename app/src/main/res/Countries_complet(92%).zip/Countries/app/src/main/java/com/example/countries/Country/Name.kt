package com.example.countries.Country

data class Name(
    val common: String,
    val nativeName: NativeName,
    val official: String
)