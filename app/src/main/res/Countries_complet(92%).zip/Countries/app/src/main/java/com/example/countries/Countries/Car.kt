package com.example.countries.Countries

data class Car(
    val side: String,
    val signs: List<String>
)