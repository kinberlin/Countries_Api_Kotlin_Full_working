package com.example.countries.Countries

data class CapitalInfo(
    val latlng: List<Double>
)