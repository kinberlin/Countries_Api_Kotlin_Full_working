package com.example.countries.Country

data class Zho(
    val common: String,
    val official: String
)