package com.example.countries.Country

data class FraX(
    val common: String,
    val official: String
)