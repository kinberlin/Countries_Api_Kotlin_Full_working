package com.example.countries.Country

data class Currencies(
    val EUR: XAF
)