package com.example.countries.Countries

data class Hrv(
    val common: String,
    val official: String
)