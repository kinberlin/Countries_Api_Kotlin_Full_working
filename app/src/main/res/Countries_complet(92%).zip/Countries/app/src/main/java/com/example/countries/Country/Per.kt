package com.example.countries.Country

data class Per(
    val common: String,
    val official: String
)