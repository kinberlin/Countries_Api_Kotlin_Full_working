package com.example.countries.Country

data class Deu(
    val common: String,
    val official: String
)