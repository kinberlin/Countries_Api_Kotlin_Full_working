package com.example.countries.Country

data class Car(
    val side: String,
    val signs: List<String>
)