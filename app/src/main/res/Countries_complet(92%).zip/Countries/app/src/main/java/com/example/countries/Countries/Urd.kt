package com.example.countries.Countries

data class Urd(
    val common: String,
    val official: String
)