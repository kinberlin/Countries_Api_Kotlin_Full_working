package com.example.countries.Countries

data class Hun(
    val common: String,
    val official: String
)