package com.example.countries.Country

data class Ita(
    val common: String,
    val official: String
)