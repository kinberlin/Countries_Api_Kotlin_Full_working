package com.example.countries.Country

class CountryClass : ArrayList<CountryClassItem>()