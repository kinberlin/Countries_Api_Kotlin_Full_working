package com.example.countries.Country

data class Eng(
    val f: String,
    val m: String
)