package com.example.countries.Countries

data class Cym(
    val common: String,
    val official: String
)