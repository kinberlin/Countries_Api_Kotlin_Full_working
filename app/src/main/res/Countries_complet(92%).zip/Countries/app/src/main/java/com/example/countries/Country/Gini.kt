package com.example.countries.Country

data class Gini(
    val `2014`: Double
)