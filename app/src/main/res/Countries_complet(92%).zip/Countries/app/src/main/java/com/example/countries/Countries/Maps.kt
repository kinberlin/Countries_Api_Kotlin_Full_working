package com.example.countries.Countries

data class Maps(
    val googleMaps: String,
    val openStreetMaps: String
)