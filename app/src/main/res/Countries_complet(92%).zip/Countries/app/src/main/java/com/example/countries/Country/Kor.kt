package com.example.countries.Country

data class Kor(
    val common: String,
    val official: String
)