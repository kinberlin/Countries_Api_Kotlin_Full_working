package com.example.countries.Countries

data class XCD(
    val name: String,
    val symbol: String
)