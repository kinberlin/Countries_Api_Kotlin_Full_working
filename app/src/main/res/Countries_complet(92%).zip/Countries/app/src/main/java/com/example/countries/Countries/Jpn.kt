package com.example.countries.Countries

data class Jpn(
    val common: String,
    val official: String
)