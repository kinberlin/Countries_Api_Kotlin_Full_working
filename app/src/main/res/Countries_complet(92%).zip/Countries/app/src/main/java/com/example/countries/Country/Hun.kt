package com.example.countries.Country

data class Hun(
    val common: String,
    val official: String
)