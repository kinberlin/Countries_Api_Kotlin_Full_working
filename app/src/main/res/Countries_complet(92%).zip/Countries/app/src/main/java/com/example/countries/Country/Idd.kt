package com.example.countries.Country

data class Idd(
    val root: String,
    val suffixes: List<String>
)