package com.example.countries.Country

data class Spa(
    val common: String,
    val official: String
)