package com.example.countries.Countries

data class Ita(
    val common: String,
    val official: String
)