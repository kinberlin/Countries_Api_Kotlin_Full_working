package com.example.countries.Countries

data class Deu(
    val common: String,
    val official: String
)