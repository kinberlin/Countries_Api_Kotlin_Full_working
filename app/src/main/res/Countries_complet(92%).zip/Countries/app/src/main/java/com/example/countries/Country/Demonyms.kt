package com.example.countries.Country

data class Demonyms(
    val eng: Eng,
    val fra: Fra
)