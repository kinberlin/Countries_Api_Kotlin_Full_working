package com.example.countries.Countries

data class Idd(
    val root: String,
    val suffixes: List<String>
)