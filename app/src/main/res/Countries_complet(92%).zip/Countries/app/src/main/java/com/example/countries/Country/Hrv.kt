package com.example.countries.Country

data class Hrv(
    val common: String,
    val official: String
)