package com.example.countries.Countries

data class Flags(
    val png: String,
    val svg: String
)