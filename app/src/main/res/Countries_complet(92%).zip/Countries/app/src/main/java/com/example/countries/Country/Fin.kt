package com.example.countries.Country

data class Fin(
    val common: String,
    val official: String
)