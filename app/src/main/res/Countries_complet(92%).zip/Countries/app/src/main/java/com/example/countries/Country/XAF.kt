package com.example.countries.Country

data class XAF(
    val name: String,
    val symbol: String
)