package com.example.countries.Countries

data class NativeName(
    val eng: EngX
)