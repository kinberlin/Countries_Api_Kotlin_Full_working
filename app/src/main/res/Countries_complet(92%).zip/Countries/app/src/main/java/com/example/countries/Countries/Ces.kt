package com.example.countries.Countries

data class Ces(
    val common: String,
    val official: String
)