package com.example.countries.Countries

data class CoatOfArms(
    val png: String,
    val svg: String
)