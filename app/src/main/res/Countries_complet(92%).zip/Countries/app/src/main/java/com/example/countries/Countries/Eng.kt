package com.example.countries.Countries

data class Eng(
    val f: String,
    val m: String
)